#!/bin/bash
set -e
LN='io.github.jliljebl.Flowblade'
SWMC='Flowblade'
#TARGET="$()"
#EXEC_OLD=''
#EXEC_NEW=''
#ICON_OLD=''
#ICON_NEW=''
#DEPS=''
#PPA=''
INSTNAME='flowblade'
source "$HOME"/.uds/functions.sh
#enter_tmp
#download
fix_launcher
install_deb