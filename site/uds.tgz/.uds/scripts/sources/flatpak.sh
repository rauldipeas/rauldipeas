#!/bin/bash
set -e
#LN=''
#SWMC=''
#TARGET="$()"
#EXEC_OLD=''
#EXEC_NEW=''
#ICON_OLD=''
#ICON_NEW=''
#DEPS=''
#PPA=''
INSTNAME='gnome-software-plugin-flatpak'
source "$HOME"/.uds/functions.sh
#enter_tmp
#download
#fix_launcher
install_deb
flatpak remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo