#!/bin/bash
set -e
#LN=''
#SWMC=''
#TARGET="$()"
#EXEC_OLD=''
#EXEC_NEW=''
#ICON_OLD=''
#ICON_NEW=''
#DEPS=''
#PPA=''
INSTNAME='tilix'
source "$HOME"/.uds/functions.sh
#enter_tmp
#download
#fix_launcher
install_deb
gsettings set org.gnome.desktop.default-applications.terminal exec tilix