#!/bin/bash
set -e
#LN=''
#SWMC=''
#TARGET="$()"
#EXEC_OLD=''
#EXEC_NEW=''
#ICON_OLD=''
#ICON_NEW=''
#DEPS=''
#PPA=''
INSTNAME="curl\
     imagemagick\
     p7zip\
     xterm\
     zenity"
source "$HOME"/.uds/functions.sh
#enter_tmp
#download
#ix_launcher
install_deb