#!/bin/bash
set -e
LN='org.gimp.GIMP.Stable'
#SWMC=''
GIMP_VER="$(wget -qO- https://www.gimp.org/downloads|grep 'stable'|head -n1|cut -d '>' -f3|cut -d '<' -f1)"
TARGET="https://download.gimp.org/gimp/v3.0/linux/GIMP-$GIMP_VER-x86_64.AppImage"
EXEC_OLD='org.gimp.GIMP.Stable'
EXEC_NEW='gimp'
ICON_OLD='org.gimp.GIMP.Stable'
ICON_NEW='gimp'
DEPS="libcanberra-gtk-module\
	gtk2-engines-murrine\
	gtk2-engines-pixbuf"
#PPA=''
#INSTNAME=''
source "$HOME"/.uds/functions.sh
#fix_launcher
install_deb
mkdir -p "$HOME"/.config/GIMP/3.0
cp "$HOME"/.uds/settings/{gimprc,sessionrc} "$HOME"/.config/GIMP/3.0
enter_tmp
download
install_appimage