#!/bin/bash
set -e

# Ubuntu derivatives studio post-install

## Post-install dependencies
bash "$PWD/scripts/deps/postinst-deps.sh"           # tools for this script
bash "$PWD/scripts/deps/apt-hooks.sh"               # hooks for apt

## UnSnap
bash "$PWD/scripts/deps/unsnap-fresh-ubuntu.sh"     # replace and remove snap

## Core
bash "$PWD/scripts/core/liquorix.sh"                # kernel
#bash "$PWD/scripts/core/cfs-zen-tweaks.sh"          # cpu scheduler
#bash "$PWD/scripts/core/nohang.sh"                  # memory handler
bash "$PWD/scripts/core/video-drivers.sh"           # video drivers
bash "$PWD/scripts/core/ubuntustudio.sh"            # system settings
bash "$PWD/scripts/core/rtcqs.sh"                   # settings checker

## Main
### Software management
bash "$PWD/scripts/sources/software-sources.sh"     # packages
bash "$PWD/scripts/sources/synaptic.sh"             # Debian package manager
### Audio
bash "$PWD/scripts/audio/musescore-studio.sh"       # music notation
bash "$PWD/scripts/audio/reaper.sh"                 # DAW
bash "$PWD/scripts/audio/artv.sh"                   # audio plugins
bash "$PWD/scripts/audio/auburnsounds.sh"           # audio plugins
bash "$PWD/scripts/audio/chowdsp.sh"                # audio plugins
bash "$PWD/scripts/audio/lsp-plugins.sh"            # audio plugins
bash "$PWD/scripts/audio/neuralrack.sh"             # audio plugin
bash "$PWD/scripts/audio/sfizz.sh"                  # sample player
bash "$PWD/scripts/audio/themasker.sh"              # audio plugin
bash "$PWD/scripts/audio/tonelib.sh"                # audio plugins
bash "$PWD/scripts/audio/q4wine.sh"                 # WINE utility
#bash "$PWD/scripts/audio/proton-ge.sh"              # Proton + optimizations
bash "$PWD/scripts/audio/wine-tkg.sh"               # WINE + FSync patch
bash "$PWD/scripts/audio/yabridge.sh"               # WINE-VST bridge
### Video
bash "$PWD/scripts/video/obs-studio.sh"             # broadcast/recording
bash "$PWD/scripts/video/iriun.sh"                  # mobile webcam
bash "$PWD/scripts/video/davinci-resolve.sh"        # video editor
bash "$PWD/scripts/video/shutter-encoder.sh"        # media converter
bash "$PWD/scripts/video/flowblade.sh"              # video editor
#bash "$PWD/scripts/video/kdenlive.sh"               # video editor
#bash "$PWD/scripts/video/glaxnimate.sh"             # animation editor

### Image
bash "$PWD/scripts/image/gimp.sh"                   # image editor

## Extras
### Browser
bash "$PWD/scripts/extras/librewolf.sh"             # web browser
bash "$PWD/scripts/extras/firefoxpwa.sh"            # progressive web apps
bash "$PWD/scripts/extras/freedownloadmanager.sh"   # download manager
### Authentication
bash "$PWD/scripts/extras/proton-pass.sh"           # password manager              # TODO
bash "$PWD/scripts/extras/ente-auth.sh"             # 2FA code generator
### Backup
bash "$PWD/scripts/extras/megasync.sh"              # cloud
bash "$PWD/scripts/extras/syncthing.sh"             # LAN sync
bash "$PWD/scripts/extras/keybase.sh"               # cloud + encrypted chat
bash "$PWD/scripts/extras/freefilesync.sh"          # folder sync
### Communication
bash "$PWD/scripts/extras/deltachat.sh"             # encrypted mail/chat
bash "$PWD/scripts/extras/rambox.sh"                # multi-messenger
### Entertainment
bash "$PWD/scripts/extras/freetube.sh"              # YouTube frontend
bash "$PWD/scripts/extras/stremio.sh"               # torrent streaming
#bash "$PWD/scripts/extras/retroarch.sh"             # retro gaming                  # TODO
### Misc
bash "$PWD/scripts/extras/tilix.sh"                 # tiling terminal
bash "$PWD/scripts/extras/cli-tools.sh"             # CLI tools
bash "$PWD/scripts/extras/virtualbox.sh"            # virtualization
bash "$PWD/scripts/extras/rustdesk.sh"              # remote access
bash "$PWD/scripts/extras/obsidian.sh"              # markdown knowledge mgr
bash "$PWD/scripts/extras/vscode.sh"                # programming IDE
bash "$PWD/scripts/extras/themes.sh"                # themes
bash "$PWD/scripts/extras/superpaper.sh"            # slideshow wallpaper
#bash "$PWD/scripts/extras/variety.sh"               # wallpaper manager
bash "$PWD/scripts/extras/diodon.sh"                # clipboard manager
bash "$PWD/scripts/extras/caffeine.sh"              # keep screen wake
#bash "$PWD/scripts/extras/ubuntu-pro.sh"            # ubuntu pro services

## Restart the system
sudo shutdown -r 0